<?php
// Ativar exibição de erros para depuração
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

// Incluir ficheiro de ligação
include 'config/ligacao.php';

// Obter estatísticas
$stats = array(
    'salas' => 0,
    'equipamentos' => 0,
    'tecnicos' => 0,
    'intervencoes' => 0,
    'intervencoes_mes' => 0
);

if (isset($conn) && !$conn->connect_error) {
    // Total de Salas
    $result = $conn->query("SELECT COUNT(*) as total FROM salas");
    if ($result) {
        $row = $result->fetch_assoc();
        $stats['salas'] = $row['total'];
    }

    // Total de Equipamentos
    $result = $conn->query("SELECT COUNT(*) as total FROM equipamentos");
    if ($result) {
        $row = $result->fetch_assoc();
        $stats['equipamentos'] = $row['total'];
    }

    // Total de Técnicos
    $result = $conn->query("SELECT COUNT(*) as total FROM tecnicos");
    if ($result) {
        $row = $result->fetch_assoc();
        $stats['tecnicos'] = $row['total'];
    }

    // Total de Intervenções
    $result = $conn->query("SELECT COUNT(*) as total FROM intervencoes");
    if ($result) {
        $row = $result->fetch_assoc();
        $stats['intervencoes'] = $row['total'];
    }

    // Intervenções neste mês
    $result = $conn->query("SELECT COUNT(*) as total FROM intervencoes WHERE MONTH(data_intervencao) = MONTH(NOW()) AND YEAR(data_intervencao) = YEAR(NOW())");
    if ($result) {
        $row = $result->fetch_assoc();
        $stats['intervencoes_mes'] = $row['total'];
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Gestão de Rede Escolar</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Dashboard Específico */
        .dashboard-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 3rem 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
        }

        .dashboard-header h2 {
            font-size: 32px;
            margin-bottom: 0.5rem;
            color: white;
            border: none;
            padding: 0;
        }

        .dashboard-header p {
            font-size: 16px;
            color: rgba(255, 255, 255, 0.9);
            margin: 0;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--bg-secondary);
            padding: 1.5rem;
            border-radius: 12px;
            border-left: 5px solid var(--primary-color);
            box-shadow: var(--shadow);
            transition: var(--transition);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
            border-left-color: var(--primary-dark);
        }

        .stat-card.salas {
            border-left-color: #3b82f6;
        }

        .stat-card.salas:hover {
            border-left-color: #1e40af;
        }

        .stat-card.equipamentos {
            border-left-color: #10b981;
        }

        .stat-card.equipamentos:hover {
            border-left-color: #059669;
        }

        .stat-card.tecnicos {
            border-left-color: #f59e0b;
        }

        .stat-card.tecnicos:hover {
            border-left-color: #d97706;
        }

        .stat-card.intervencoes {
            border-left-color: #ef4444;
        }

        .stat-card.intervencoes:hover {
            border-left-color: #dc2626;
        }

        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--text-primary);
            margin: 0.5rem 0;
        }

        .stat-label {
            font-size: 13px;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
        }

        .stat-icon {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }

        .dashboard-links {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .card {
            background: var(--bg-primary);
            border: 2px solid var(--border-color);
            border-radius: 12px;
            padding: 1.5rem;
            transition: var(--transition);
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-lg);
            border-color: var(--primary-color);
        }

        .card-icon {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }

        .card h3 {
            font-size: 20px;
            font-weight: 700;
            color: var(--primary-color);
            margin: 0;
        }

        .card p {
            color: var(--text-secondary);
            font-size: 14px;
            line-height: 1.6;
            margin: 0;
            flex-grow: 1;
        }

        .card .btn {
            align-self: flex-start;
            margin-top: 0.5rem;
        }

        .info-section {
            background: var(--bg-secondary);
            padding: 1.5rem;
            border-radius: 12px;
            border-left: 4px solid var(--info-color);
            margin-bottom: 2rem;
        }

        .info-section h3 {
            color: var(--info-color);
            margin-top: 0;
        }

        .info-section p {
            color: var(--text-secondary);
            margin: 0.5rem 0;
        }

        .quick-actions {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            margin-top: 1rem;
        }

        .quick-actions .btn {
            flex: 1;
            min-width: 150px;
            text-align: center;
        }

        .welcome-message {
            font-size: 18px;
            color: rgba(255, 255, 255, 0.95);
            margin-bottom: 1rem;
        }

        .recent-activity {
            background: var(--bg-secondary);
            padding: 1.5rem;
            border-radius: 12px;
            margin-top: 2rem;
        }

        .activity-item {
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            font-size: 1.5rem;
        }

        .activity-text {
            flex-grow: 1;
        }

        .activity-text strong {
            color: var(--text-primary);
        }

        .activity-text small {
            color: var(--text-secondary);
            display: block;
            margin-top: 0.25rem;
        }

        @media (max-width: 768px) {
            .dashboard-header {
                padding: 2rem 1.5rem;
            }

            .dashboard-header h2 {
                font-size: 24px;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 1rem;
            }

            .stat-number {
                font-size: 2rem;
            }

            .dashboard-links {
                grid-template-columns: 1fr;
            }

            .quick-actions .btn {
                min-width: auto;
            }
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const theme = localStorage.getItem('theme') || 'light';
            document.documentElement.setAttribute('data-theme', theme);
        });

        function toggleTheme() {
            const html = document.documentElement;
            const currentTheme = html.getAttribute('data-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            
            html.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            updateThemeIcon();
        }

        function updateThemeIcon() {
            const theme = document.documentElement.getAttribute('data-theme');
            const icon = document.getElementById('theme-icon');
            if (icon) {
                icon.textContent = theme === 'light' ? '🌙' : '☀️';
            }
        }

        window.addEventListener('load', updateThemeIcon);
    </script>
</head>
<body>
    <header>
        <button class="theme-toggle" onclick="toggleTheme()" title="Alternar Modo Escuro">
            <span id="theme-icon">🌙</span>
        </button>

        <h1>🌐 Sistema de Gestão de Infraestrutura de Rede</h1>
        <nav>
            <ul>
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="pages/salas.php">Salas</a></li>
                <li><a href="pages/equipamentos.php">Equipamentos</a></li>
                <li><a href="pages/tecnicos.php">Técnicos</a></li>
                <li><a href="pages/intervencoes.php">Intervenções</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div class="dashboard-header">
            <div class="welcome-message">
                Bem-vindo ao Sistema de Gestão de Infraestrutura de Rede
            </div>
            <h2>Dashboard de Gestão</h2>
            <p>Visualize e gerencie toda a infraestrutura de rede da sua escola de forma centralizada e eficiente.</p>
        </div>

        <!-- Estatísticas -->
        <div class="stats-grid">
            <div class="stat-card salas">
                <div class="stat-icon">🏛️</div>
                <div class="stat-label">Total de Salas</div>
                <div class="stat-number"><?php echo $stats['salas']; ?></div>
            </div>

            <div class="stat-card equipamentos">
                <div class="stat-icon">🖥️</div>
                <div class="stat-label">Total de Equipamentos</div>
                <div class="stat-number"><?php echo $stats['equipamentos']; ?></div>
            </div>

            <div class="stat-card tecnicos">
                <div class="stat-icon">👨‍💼</div>
                <div class="stat-label">Total de Técnicos</div>
                <div class="stat-number"><?php echo $stats['tecnicos']; ?></div>
            </div>

            <div class="stat-card intervencoes">
                <div class="stat-icon">🔧</div>
                <div class="stat-label">Total de Intervenções</div>
                <div class="stat-number"><?php echo $stats['intervencoes']; ?></div>
            </div>
        </div>

        <!-- Informações Gerais -->
        <div class="info-section">
            <h3>ℹ️ Sobre este Sistema</h3>
            <p>Este é um sistema completo de gestão de infraestrutura de rede escolar que permite organizar e controlar toda a rede da instituição.</p>
            <p><strong>Funcionalidades:</strong> Gestão de salas, equipamentos, técnicos e registo de intervenções de manutenção.</p>
        </div>

        <!-- Cartões de Acesso Rápido -->
        <section>
            <h2>⚡ Acesso Rápido</h2>
            <div class="dashboard-links">
                <div class="card">
                    <div class="card-icon">🏛️</div>
                    <h3>Gestão de Salas</h3>
                    <p>Gerir as salas onde os equipamentos de rede estão instalados e organizados.</p>
                    <a href="pages/salas.php" class="btn">Ir para Salas</a>
                </div>

                <div class="card">
                    <div class="card-icon">🖥️</div>
                    <h3>Gestão de Equipamentos</h3>
                    <p>Controlar routers, switches, access points e outros equipamentos de rede.</p>
                    <a href="pages/equipamentos.php" class="btn">Ir para Equipamentos</a>
                </div>

                <div class="card">
                    <div class="card-icon">👨‍💼</div>
                    <h3>Gestão de Técnicos</h3>
                    <p>Gerir a equipa de técnicos responsáveis pela manutenção da infraestrutura.</p>
                    <a href="pages/tecnicos.php" class="btn">Ir para Técnicos</a>
                </div>

                <div class="card">
                    <div class="card-icon">🔧</div>
                    <h3>Registo de Intervenções</h3>
                    <p>Registar e consultar o histórico completo de manutenção e reparações.</p>
                    <a href="pages/intervencoes.php" class="btn">Ir para Intervenções</a>
                </div>
            </div>
        </section>

        <!-- Resumo de Atividade -->
        <section>
            <h2>📊 Resumo de Atividade</h2>
            <div class="recent-activity">
                <div class="activity-item">
                    <div class="activity-icon">🔧</div>
                    <div class="activity-text">
                        <strong>Intervenções neste mês:</strong>
                        <small><?php echo $stats['intervencoes_mes']; ?> intervenção(ões) registada(s) em <?php echo date('F', mktime(0, 0, 0, date('m'), 1)); ?></small>
                    </div>
                </div>
                <div class="activity-item">
                    <div class="activity-icon">🖥️</div>
                    <div class="activity-text">
                        <strong>Equipamentos em salas:</strong>
                        <small><?php echo $stats['equipamentos']; ?> equipamento(s) distribuído(s) por <?php echo $stats['salas']; ?> sala(s)</small>
                    </div>
                </div>
                <div class="activity-item">
                    <div class="activity-icon">👨‍💼</div>
                    <div class="activity-text">
                        <strong>Equipa técnica:</strong>
                        <small><?php echo $stats['tecnicos']; ?> técnico(s) disponível(is) para manutenção</small>
                    </div>
                </div>
            </div>
        </section>

        <!-- Ações Rápidas -->
        <section>
            <h2>⚙️ Ações Rápidas</h2>
            <div class="quick-actions">
                <a href="pages/salas.php" class="btn">Criar Nova Sala</a>
                <a href="pages/equipamentos.php" class="btn">Registar Equipamento</a>
                <a href="pages/tecnicos.php" class="btn">Adicionar Técnico</a>
                <a href="pages/intervencoes.php" class="btn">Registar Intervenção</a>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 - Sistema de Gestão de Rede Escolar - GPSI | Dashboard Profissional com Modo Escuro</p>
    </footer>
</body>
</html>
