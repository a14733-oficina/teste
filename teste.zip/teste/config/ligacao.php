<?php
$host = "sql300.infinityfree.com";
$dbname = "if0_40156192_gestao_rede";
$user = "if0_40156192";
$pass = "KvvvlymTmFbj6aQ";

try {
    $conn = new mysqli($host, $user, $pass, $dbname);
    
    // Verificar a ligação
    if ($conn->connect_error) {
        die("Erro na ligação à BD: " . $conn->connect_error);
    }
    
    // Definir charset para UTF-8
    $conn->set_charset("utf8");
} catch (Exception $e) {
    die("Erro na ligação à BD: " . $e->getMessage());
}
?>