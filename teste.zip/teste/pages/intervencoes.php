<?php
// Ativar exibição de erros
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

// Incluir ficheiro de tema
include '../config/theme.php';

// Incluir ficheiro de ligação
include '../config/ligacao.php';

// Verificar se a ligação foi estabelecida
if (!isset($conn) || $conn->connect_error) {
    die("<h2>❌ Erro: Ligação à base de dados não foi estabelecida.</h2>");
}

// Inserir Intervenção
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['inserir_intervencao'])) {
    $data_intervencao = isset($_POST['data_intervencao']) ? trim($_POST['data_intervencao']) : '';
    $descricao = isset($_POST['descricao']) ? trim($_POST['descricao']) : '';
    $id_equipamento = isset($_POST['id_equipamento']) ? intval($_POST['id_equipamento']) : 0;
    $id_tecnico = isset($_POST['id_tecnico']) ? intval($_POST['id_tecnico']) : 0;

    if (!empty($data_intervencao) && !empty($descricao) && !empty($id_equipamento) && !empty($id_tecnico)) {
        $stmt = $conn->prepare("INSERT INTO intervencoes (data_intervencao, descricao, id_equipamento, id_tecnico) VALUES (?, ?, ?, ?)");
        if ($stmt === false) {
            die("<h2>❌ Erro ao preparar a query: " . htmlspecialchars($conn->error) . "</h2>");
        }
        $stmt->bind_param("ssii", $data_intervencao, $descricao, $id_equipamento, $id_tecnico);
        if (!$stmt->execute()) {
            die("<h2>❌ Erro ao inserir intervenção: " . htmlspecialchars($stmt->error) . "</h2>");
        }
        $stmt->close();
        header("Location: intervencoes.php");
        exit();
    }
}

// Query: Intervenções por equipamento (Filtro)
$id_equipamento_filtro = isset($_GET['id_equipamento']) ? intval($_GET['id_equipamento']) : '';
$sql_q2 = "SELECT i.*, e.marca, e.modelo, t.nome as nome_tecnico 
           FROM intervencoes i 
           JOIN equipamentos e ON i.id_equipamento = e.id_equipamento 
           JOIN tecnicos t ON i.id_tecnico = t.id_tecnico";
if (!empty($id_equipamento_filtro)) {
    $sql_q2 .= " WHERE i.id_equipamento = " . $id_equipamento_filtro;
}
$result_q2 = $conn->query($sql_q2);
if ($result_q2 === false) {
    die("<h2>❌ Erro ao listar intervenções por equipamento: " . htmlspecialchars($conn->error) . "</h2>");
}

// Query: Intervenções por técnico (Filtro)
$id_tecnico_filtro = isset($_GET['id_tecnico_filtro']) ? intval($_GET['id_tecnico_filtro']) : '';
$sql_q3 = "SELECT i.*, e.marca, e.modelo, t.nome as nome_tecnico 
           FROM intervencoes i 
           JOIN equipamentos e ON i.id_equipamento = e.id_equipamento 
           JOIN tecnicos t ON i.id_tecnico = t.id_tecnico";
if (!empty($id_tecnico_filtro)) {
    $sql_q3 .= " WHERE i.id_tecnico = " . $id_tecnico_filtro;
} else {
    $sql_q3 .= " ORDER BY t.nome, i.data_intervencao DESC";
}
$result_q3 = $conn->query($sql_q3);
if ($result_q3 === false) {
    die("<h2>❌ Erro ao listar intervenções por técnico: " . htmlspecialchars($conn->error) . "</h2>");
}

// Obter Equipamentos e Técnicos para o Formulário e Filtros
$equipamentos_result = $conn->query("SELECT id_equipamento, marca, modelo FROM equipamentos");
if ($equipamentos_result === false) {
    die("<h2>❌ Erro ao listar equipamentos: " . htmlspecialchars($conn->error) . "</h2>");
}

$tecnicos_result = $conn->query("SELECT id_tecnico, nome FROM tecnicos");
if ($tecnicos_result === false) {
    die("<h2>❌ Erro ao listar técnicos: " . htmlspecialchars($conn->error) . "</h2>");
}

$tecnicos_filtro_result = $conn->query("SELECT id_tecnico, nome FROM tecnicos");
if ($tecnicos_filtro_result === false) {
    die("<h2>❌ Erro ao listar técnicos para filtro: " . htmlspecialchars($conn->error) . "</h2>");
}

?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registo de Intervenções</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        /* Aplicar tema via PHP */
        :root {
            <?php if ($theme === 'dark'): ?>
                --bg-primary: #1a1a1a;
                --bg-secondary: #2d2d2d;
                --text-primary: #ffffff;
                --text-secondary: #b0b0b0;
                --border-color: #404040;
                --primary-color: #667eea;
                --primary-dark: #5568d3;
                --info-color: #3b82f6;
                --shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
                --shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.4);
                --transition: all 0.3s ease;
            <?php else: ?>
                --bg-primary: #ffffff;
                --bg-secondary: #f8f9fa;
                --text-primary: #1a1a1a;
                --text-secondary: #666666;
                --border-color: #e0e0e0;
                --primary-color: #667eea;
                --primary-dark: #5568d3;
                --info-color: #3b82f6;
                --shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                --shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.15);
                --transition: all 0.3s ease;
            <?php endif; ?>
        }

        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
        }
    </style>
    <script>
               
        function updateThemeIcon() {
            const theme = document.documentElement.getAttribute('data-theme');
            const icon = document.getElementById('theme-icon');
            if (icon) {
                icon.textContent = theme === 'light' ? '🌙' : '☀️';
            }
        }
       </script>
</head>
<body>
    <header>

        <h1>🔧 Registo de Intervenções</h1>
        <nav>
            <ul>
                <li><a href="../index.php">Dashboard</a></li>
                <li><a href="salas.php">Salas</a></li>
                <li><a href="equipamentos.php">Equipamentos</a></li>
                <li><a href="tecnicos.php">Técnicos</a></li>
                <li><a href="intervencoes.php">Intervenções</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>➕ Inserir Nova Intervenção</h2>
            <form method="POST" action="intervencoes.php">
                <div class="form-group">
                    <label for="data_intervencao">Data:</label>
                    <input type="date" name="data_intervencao" id="data_intervencao" required>
                </div>
                
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <textarea name="descricao" id="descricao" placeholder="Descreva a intervenção realizada..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label for="id_equipamento">Equipamento:</label>
                    <select name="id_equipamento" id="id_equipamento" required>
                        <option value="">-- Selecione um Equipamento --</option>
                        <?php 
                        if ($equipamentos_result->num_rows > 0) {
                            while($eq = $equipamentos_result->fetch_assoc()): 
                        ?>
                        <option value="<?php echo $eq['id_equipamento']; ?>"><?php echo htmlspecialchars($eq['marca'] . " " . $eq['modelo']); ?></option>
                        <?php 
                            endwhile;
                        }
                        ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="id_tecnico">Técnico:</label>
                    <select name="id_tecnico" id="id_tecnico" required>
                        <option value="">-- Selecione um Técnico --</option>
                        <?php 
                        if ($tecnicos_result->num_rows > 0) {
                            while($tec = $tecnicos_result->fetch_assoc()): 
                        ?>
                        <option value="<?php echo $tec['id_tecnico']; ?>"><?php echo htmlspecialchars($tec['nome']); ?></option>
                        <?php 
                            endwhile;
                        }
                        ?>
                    </select>
                </div>
                
                <button type="submit" name="inserir_intervencao" class="btn">Registar Intervenção</button>
            </form>
        </section>

        <section>
            <h2>📊 Histórico de Intervenções por Equipamento</h2>
            <?php if (!empty($id_equipamento_filtro)): ?>
                <h3>Histórico do Equipamento ID: <?php echo intval($id_equipamento_filtro); ?></h3>
                <p><a href="intervencoes.php" class="btn-secondary">Limpar Filtro</a></p>
            <?php else: ?>
                <h3>Selecione um equipamento na <a href="equipamentos.php">página de equipamentos</a> para ver o seu histórico.</h3>
            <?php endif; ?>
            <table>
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>Descrição</th>
                        <th>Técnico Responsável</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result_q2->num_rows > 0): ?>
                        <?php while($row = $result_q2->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['data_intervencao']); ?></td>
                            <td><?php echo htmlspecialchars($row['descricao']); ?></td>
                            <td><?php echo htmlspecialchars($row['nome_tecnico']); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="3" class="text-center">Nenhuma intervenção encontrada para este equipamento.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>

        <section>
            <h2>👨‍💼 Intervenções por Técnico</h2>
            <form method="GET" action="intervencoes.php">
                <div class="form-group">
                    <label for="id_tecnico_filtro">Filtrar por Técnico:</label>
                    <select name="id_tecnico_filtro" id="id_tecnico_filtro" onchange="this.form.submit()">
                        <option value="">Todos os Técnicos</option>
                        <?php 
                        if ($tecnicos_filtro_result->num_rows > 0) {
                            while($tec = $tecnicos_filtro_result->fetch_assoc()): 
                        ?>
                        <option value="<?php echo $tec['id_tecnico']; ?>" <?php echo ($id_tecnico_filtro == $tec['id_tecnico']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($tec['nome']); ?>
                        </option>
                        <?php 
                            endwhile;
                        }
                        ?>
                    </select>
                </div>
            </form>
            <table>
                <thead>
                    <tr>
                        <th>Técnico</th>
                        <th>Data</th>
                        <th>Equipamento</th>
                        <th>Descrição</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result_q3->num_rows > 0): ?>
                        <?php while($row = $result_q3->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['nome_tecnico']); ?></td>
                            <td><?php echo htmlspecialchars($row['data_intervencao']); ?></td>
                            <td><?php echo htmlspecialchars($row['marca'] . ' ' . $row['modelo']); ?></td>
                            <td><?php echo htmlspecialchars($row['descricao']); ?></td>
                        </tr>
                        <?php endwhile; ?>
                     <?php else: ?>
                        <tr><td colspan="4" class="text-center">Nenhuma intervenção encontrada para este técnico.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 - Sistema de Gestão de Rede Escolar - GPSI</p>
    </footer>
</body>
</html>
