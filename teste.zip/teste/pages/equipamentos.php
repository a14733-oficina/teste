<?php
// Ativar exibição de erros
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

// Incluir ficheiro de tema
include '../config/theme.php';

// Incluir ficheiro de ligação
include '../config/ligacao.php';

// Verificar se a ligação foi estabelecida
if (!isset($conn) || $conn->connect_error) {
    die("<h2>❌ Erro: Ligação à base de dados não foi estabelecida.</h2>");
}

// Inserir Equipamento
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['inserir_equipamento'])) {
    $tipo = isset($_POST['tipo']) ? trim($_POST['tipo']) : '';
    $marca = isset($_POST['marca']) ? trim($_POST['marca']) : '';
    $modelo = isset($_POST['modelo']) ? trim($_POST['modelo']) : '';
    $endereco_ip = isset($_POST['endereco_ip']) ? trim($_POST['endereco_ip']) : '';
    $id_sala = isset($_POST['id_sala']) ? intval($_POST['id_sala']) : 0;

    if (!empty($tipo) && !empty($marca) && !empty($modelo) && !empty($endereco_ip) && !empty($id_sala)) {
        $stmt = $conn->prepare("INSERT INTO equipamentos (tipo, marca, modelo, endereco_ip, id_sala) VALUES (?, ?, ?, ?, ?)");
        if ($stmt === false) {
            die("<h2>❌ Erro ao preparar a query: " . htmlspecialchars($conn->error) . "</h2>");
        }
        $stmt->bind_param("ssssi", $tipo, $marca, $modelo, $endereco_ip, $id_sala);
        if (!$stmt->execute()) {
            die("<h2>❌ Erro ao inserir equipamento: " . htmlspecialchars($stmt->error) . "</h2>");
        }
        $stmt->close();
        header("Location: equipamentos.php");
        exit();
    }
}

// Query: Equipamentos por sala (Filtro)
$id_sala_filtro = isset($_GET['id_sala_filtro']) ? intval($_GET['id_sala_filtro']) : '';
$sql_q1 = "SELECT e.*, s.nome_sala FROM equipamentos e JOIN salas s ON e.id_sala = s.id_sala";
if (!empty($id_sala_filtro)) {
    $sql_q1 .= " WHERE e.id_sala = " . $id_sala_filtro;
}
$result_q1 = $conn->query($sql_q1);
if ($result_q1 === false) {
    die("<h2>❌ Erro ao listar equipamentos por sala: " . htmlspecialchars($conn->error) . "</h2>");
}

// Query: Equipamentos sem intervenções
$sql_q4 = "SELECT e.*, s.nome_sala 
           FROM equipamentos e 
           JOIN salas s ON e.id_sala = s.id_sala 
           LEFT JOIN intervencoes i ON e.id_equipamento = i.id_equipamento 
           WHERE i.id_intervencao IS NULL";
$result_q4 = $conn->query($sql_q4);
if ($result_q4 === false) {
    die("<h2>❌ Erro ao listar equipamentos sem intervenções: " . htmlspecialchars($conn->error) . "</h2>");
}

// Obter Salas para os Formulários/Filtros
$salas_result = $conn->query("SELECT * FROM salas");
if ($salas_result === false) {
    die("<h2>❌ Erro ao listar salas: " . htmlspecialchars($conn->error) . "</h2>");
}

$salas_filtro_result = $conn->query("SELECT * FROM salas");
if ($salas_filtro_result === false) {
    die("<h2>❌ Erro ao listar salas para filtro: " . htmlspecialchars($conn->error) . "</h2>");
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Equipamentos</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        /* Aplicar tema via PHP */
        :root {
            <?php if ($theme === 'dark'): ?>
                --bg-primary: #1a1a1a;
                --bg-secondary: #2d2d2d;
                --text-primary: #ffffff;
                --text-secondary: #b0b0b0;
                --border-color: #404040;
                --primary-color: #667eea;
                --primary-dark: #5568d3;
                --info-color: #3b82f6;
                --shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
                --shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.4);
                --transition: all 0.3s ease;
            <?php else: ?>
                --bg-primary: #ffffff;
                --bg-secondary: #f8f9fa;
                --text-primary: #1a1a1a;
                --text-secondary: #666666;
                --border-color: #e0e0e0;
                --primary-color: #667eea;
                --primary-dark: #5568d3;
                --info-color: #3b82f6;
                --shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                --shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.15);
                --transition: all 0.3s ease;
            <?php endif; ?>
        }

        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const theme = localStorage.getItem('theme') || 'light';
            document.documentElement.setAttribute('data-theme', theme);
        });

        function toggleTheme() {
            const html = document.documentElement;
            const currentTheme = html.getAttribute('data-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            
            html.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            updateThemeIcon();
        }

        function updateThemeIcon() {
            const theme = document.documentElement.getAttribute('data-theme');
            const icon = document.getElementById('theme-icon');
            if (icon) {
                icon.textContent = theme === 'light' ? '🌙' : '☀️';
            }
        }

        window.addEventListener('load', updateThemeIcon);
    </script>
</head>
<body>
    <header>
  
        <h1>🖥️ Gestão de Equipamentos</h1>
        <nav>
            <ul>
                <li><a href="../index.php">Dashboard</a></li>
                <li><a href="salas.php">Salas</a></li>
                <li><a href="equipamentos.php">Equipamentos</a></li>
                <li><a href="tecnicos.php">Técnicos</a></li>
                <li><a href="intervencoes.php">Intervenções</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>➕ Inserir Novo Equipamento</h2>
            <form method="POST" action="equipamentos.php">
                <div class="form-group">
                    <label for="tipo">Tipo:</label>
                    <select name="tipo" id="tipo" required>
                        <option value="">-- Selecione um Tipo --</option>
                        <option value="router">Router</option>
                        <option value="switch">Switch</option>
                        <option value="access point">Access Point</option>
                        <option value="outro">Outro</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="marca">Marca:</label>
                    <input type="text" name="marca" id="marca" placeholder="Ex: Cisco" required>
                </div>
                
                <div class="form-group">
                    <label for="modelo">Modelo:</label>
                    <input type="text" name="modelo" id="modelo" placeholder="Ex: C2900XL" required>
                </div>
                
                <div class="form-group">
                    <label for="endereco_ip">Endereço IP:</label>
                    <input type="text" name="endereco_ip" id="endereco_ip" placeholder="Ex: 192.168.1.1" required>
                </div>
                
                <div class="form-group">
                    <label for="id_sala">Sala:</label>
                    <select name="id_sala" id="id_sala" required>
                        <option value="">-- Selecione uma Sala --</option>
                        <?php 
                        if ($salas_result->num_rows > 0) {
                            while($sala = $salas_result->fetch_assoc()): 
                        ?>
                        <option value="<?php echo $sala['id_sala']; ?>"><?php echo htmlspecialchars($sala['nome_sala']); ?></option>
                        <?php 
                            endwhile;
                        }
                        ?>
                    </select>
                </div>
                
                <button type="submit" name="inserir_equipamento" class="btn">Inserir Equipamento</button>
            </form>
        </section>

        <section>
            <h2>📊 Equipamentos por Sala</h2>
            <form method="GET" action="equipamentos.php">
                <div class="form-group">
                    <label for="id_sala_filtro">Filtrar por Sala:</label>
                    <select name="id_sala_filtro" id="id_sala_filtro" onchange="this.form.submit()">
                        <option value="">Todas as Salas</option>
                        <?php 
                        if ($salas_filtro_result->num_rows > 0) {
                            while($sala = $salas_filtro_result->fetch_assoc()): 
                        ?>
                        <option value="<?php echo $sala['id_sala']; ?>" <?php echo ($id_sala_filtro == $sala['id_sala']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($sala['nome_sala']); ?>
                        </option>
                        <?php 
                            endwhile;
                        }
                        ?>
                    </select>
                </div>
            </form>
            <table>
                <thead>
                    <tr>
                        <th>Sala</th>
                        <th>Tipo</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>IP</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if ($result_q1->num_rows > 0) {
                        while($row = $result_q1->fetch_assoc()): 
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['nome_sala']); ?></td>
                        <td><?php echo htmlspecialchars($row['tipo']); ?></td>
                        <td><?php echo htmlspecialchars($row['marca']); ?></td>
                        <td><?php echo htmlspecialchars($row['modelo']); ?></td>
                        <td><?php echo htmlspecialchars($row['endereco_ip']); ?></td>
                        <td><a href="intervencoes.php?id_equipamento=<?php echo $row['id_equipamento']; ?>" class="btn btn-small">Ver Histórico</a></td>
                    </tr>
                    <?php 
                        endwhile;
                    } else {
                        echo "<tr><td colspan='6' class='text-center'>Nenhum equipamento encontrado.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>

        <section>
            <h2>⚠️ Equipamentos sem Intervenções</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tipo</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Sala</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result_q4->num_rows > 0): ?>
                        <?php while($row = $result_q4->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['id_equipamento']); ?></td>
                            <td><?php echo htmlspecialchars($row['tipo']); ?></td>
                            <td><?php echo htmlspecialchars($row['marca']); ?></td>
                            <td><?php echo htmlspecialchars($row['modelo']); ?></td>
                            <td><?php echo htmlspecialchars($row['nome_sala']); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center">Todos os equipamentos já tiveram intervenções.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 - Sistema de Gestão de Rede Escolar - GPSI</p>
    </footer>
</body>
</html>
