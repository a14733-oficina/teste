<?php
// Ativar exibição de erros
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

// Incluir ficheiro de tema
include '../config/theme.php';

// Incluir ficheiro de ligação
include '../config/ligacao.php';

// Verificar se a ligação foi estabelecida
if (!isset($conn) || $conn->connect_error) {
    die("<h2>❌ Erro: Ligação à base de dados não foi estabelecida.</h2>");
}

// Inserir Sala
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['inserir_sala'])) {
    $nome_sala = isset($_POST['nome_sala']) ? trim($_POST['nome_sala']) : '';
    $localizacao = isset($_POST['localizacao']) ? trim($_POST['localizacao']) : '';

    if (!empty($nome_sala) && !empty($localizacao)) {
        $stmt = $conn->prepare("INSERT INTO salas (nome_sala, localizacao) VALUES (?, ?)");
        if ($stmt === false) {
            die("<h2>❌ Erro ao preparar a query: " . htmlspecialchars($conn->error) . "</h2>");
        }
        $stmt->bind_param("ss", $nome_sala, $localizacao);
        if (!$stmt->execute()) {
            die("<h2>❌ Erro ao inserir sala: " . htmlspecialchars($stmt->error) . "</h2>");
        }
        $stmt->close();
        header("Location: salas.php");
        exit();
    }
}

// Listar Salas
$result = $conn->query("SELECT * FROM salas");
if ($result === false) {
    die("<h2>❌ Erro ao listar salas: " . htmlspecialchars($conn->error) . "</h2>");
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Salas</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        /* Aplicar tema via PHP */
        :root {
            <?php if ($theme === 'dark'): ?>
                --bg-primary: #1a1a1a;
                --bg-secondary: #2d2d2d;
                --text-primary: #ffffff;
                --text-secondary: #b0b0b0;
                --border-color: #404040;
                --primary-color: #667eea;
                --primary-dark: #5568d3;
                --info-color: #3b82f6;
                --shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
                --shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.4);
                --transition: all 0.3s ease;
            <?php else: ?>
                --bg-primary: #ffffff;
                --bg-secondary: #f8f9fa;
                --text-primary: #1a1a1a;
                --text-secondary: #666666;
                --border-color: #e0e0e0;
                --primary-color: #667eea;
                --primary-dark: #5568d3;
                --info-color: #3b82f6;
                --shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                --shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.15);
                --transition: all 0.3s ease;
            <?php endif; ?>
        }

        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
        }
    </style>
</head>
<body>
    <header>
        <a href="salas.php?toggle_theme=1" class="theme-toggle" title="Alternar Modo Escuro">
            <span><?php echo ($theme === 'light') ? '🌙' : '☀️'; ?></span>
        </a>

        <h1>🏛️ Gestão de Salas</h1>
        <nav>
            <ul>
                <li><a href="../index.php">Dashboard</a></li>
                <li><a href="salas.php">Salas</a></li>
                <li><a href="equipamentos.php">Equipamentos</a></li>
                <li><a href="tecnicos.php">Técnicos</a></li>
                <li><a href="intervencoes.php">Intervenções</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>➕ Inserir Nova Sala</h2>
            <form method="POST" action="salas.php">
                <div class="form-group">
                    <label for="nome_sala">Nome da Sala:</label>
                    <input type="text" name="nome_sala" id="nome_sala" placeholder="Ex: Sala de Informática A" required>
                </div>
                
                <div class="form-group">
                    <label for="localizacao">Localização:</label>
                    <input type="text" name="localizacao" id="localizacao" placeholder="Ex: Bloco B, 2º Andar" required>
                </div>
                
                <button type="submit" name="inserir_sala" class="btn">Inserir Sala</button>
            </form>
        </section>

        <section>
            <h2>📋 Lista de Salas</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome da Sala</th>
                        <th>Localização</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()): 
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id_sala']); ?></td>
                        <td><?php echo htmlspecialchars($row['nome_sala']); ?></td>
                        <td><?php echo htmlspecialchars($row['localizacao']); ?></td>
                    </tr>
                    <?php 
                        endwhile;
                    } else {
                        echo "<tr><td colspan='3' class='text-center'>Nenhuma sala registada.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 - Sistema de Gestão de Rede Escolar - GPSI</p>
    </footer>
</body>
</html>
